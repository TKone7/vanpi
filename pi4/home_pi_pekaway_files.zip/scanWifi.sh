#! /bin/sh
sudo iwlist wlan0 scan > ~/pekaway/availableWifi.txt && 
sudo chmod 0777 ~/pekaway/availableWifi.txt && 
sudo grep -E "ESSID:" ~/pekaway/availableWifi.txt > ~/pekaway/WifiScanResult1.txt &&
sed -e 's/.*"\(.*\)"/\1/' ~/pekaway/WifiScanResult1.txt > ~/pekaway/WifiScanResult.txt &&
sed -i '/^$/d' ~/pekaway/WifiScanResult.txt