# About

This folder contains tools for controlling rc remote controlled power sockets
with [C.H.I.P](getchip.com) devices.


## Usage

After that you can compile the example program *send* by executing *make*. 

## Note
The 'send' and 'sendcode' code is as yet untested.  It _should_ work, but it is still being tested thoroughly.  It's provided to allow you to start playing with it now.
