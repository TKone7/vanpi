#!/bin/bash

sudo cp /etc/dhcpcd_nonap.conf /etc/dhcpcd.conf && 
sudo systemctl disable hostapd dnsmasq && 
sudo systemctl stop hostapd dnsmasq && 
sudo nohup sh -c 'ip addr flush dev wlan0 &&
sudo systemctl restart dhcpcd.service' >/dev/null &&
sudo ip link set wlan0 up &
