#! /bin/sh

if [ "$(whoami)" != "root" ]
then
    sudo su -s "$0"
    exit
fi

cat /home/pi/pekaway/newWifi.txt >> /etc/wpa_supplicant/wpa_supplicant.conf