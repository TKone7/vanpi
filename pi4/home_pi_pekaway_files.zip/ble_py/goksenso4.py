#!/usr/bin/env python3

# LIONTRON LX Smart BMS 12,8V 100Ah - bought 2021
# Get Values from BMS and print as JSON
#
# Issues:
# Sometimes the connections does not work "connect error: Function not implemented (38)" : dont know why
# Sometimes there are no values "Characteristic value was written successfully" : dont know why
# Sometimes the connections does not work without any error : there might be another client connected
# "Device or resource busy" : there might be still an open connection on the client, restart your bluetooth if you can't find it
#
# request bytes: header (two bytes), command (two bytes), checksum (two bytes), EOR (one byte b'77')
# response bytes: header (two bytes), lenght in bytes (two bytes), data, checksum (two bytes), EOR (one byte b'77')
#
# Unused Data Bytes Request 1 (unsure if correct):  10,11:proddate; 12-15:balance status; 18:software version; 20:mosfet status; 21:cell count; 22:ntc count

import argparse
import pexpect
import json

# Command line parameters
parser = argparse.ArgumentParser()
parser.add_argument("-d", "--device", dest = "device", help="Specify remote Bluetooth address", metavar="MAC", required=True)
parser.add_argument("-v", "--verbose", dest = "v", help="Verbosity", action='count', default=0)
args = parser.parse_args()

# Run gatttool interactively.
child = pexpect.spawn("gatttool -I -t random -b {0}".format(args.device))

# Connect to the device
for attempt in range(10):
    try:
        if args.v: print("Scale connecting (Try:", attempt+1, ")")
        child.sendline("connect")
        child.expect("Connection successful", timeout=1)
    except pexpect.TIMEOUT:
        if args.v==2: print(child.before)
        continue
    else:
        if args.v: print("Scale connection successful")
        break
else:
    if args.v: print ("Scale Connect timeout! Exit")
    child.sendline("exit")
    print ("Connection timed out!")
    exit()    

# Request data until data is recieved or max attempt is reached
# Voltage and other information
for attempt in range(1):
    try:
        resp=b''
        if args.v: print("Scale requesting data 1 (Try:", attempt+1, ")")
        child.sendline("char-read-uuid 00007082-a20b-4d4d-a4de-7f071dbbc1d8")
        child.expect("handle: 0x000e \t value: ", timeout=5)
        child.expect("\r\n", timeout=0)
        if args.v: print("Scale received data 1")
        if args.v==2: print("Scale answer 1: ", child.before)
        resp+=child.before
    except pexpect.TIMEOUT:
        continue
    else:
        break
else:
    resp=b''
    if args.v: print ("Scale Answering timeout!")
    if args.v==2: print(child.before)


# Close connection
if args.v: print("Scale disconnecting")
child.sendline("disconnect")
child.sendline("exit")


if args.v: print("Response 1:", resp)

resp = resp[:-1]

# Print JSON
print (resp)
