#! /bin/sh

if [ "$(whoami)" != "root" ]
then
    sudo su -s "$0"
    exit
fi

cat ~/pekaway/newWifi.txt >> /etc/wpa_supplicant/wpa_supplicant.conf