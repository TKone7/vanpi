#! /bin/sh
sudo iwlist wlan0 scan > /home/pi/pekaway/availableWifi.txt && 
sudo chmod 0777 /home/pi/pekaway/availableWifi.txt && 
sudo grep -E "ESSID:" /home/pi/pekaway/availableWifi.txt > /home/pi/pekaway/WifiScanResult1.txt &&
sed -e 's/.*"\(.*\)"/\1/' /home/pi/pekaway/WifiScanResult1.txt > /home/pi/pekaway/WifiScanResult.txt &&
sed -i '/^$/d' /home/pi/pekaway/WifiScanResult.txt